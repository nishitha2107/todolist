var input = document.getElementById("inputItem");
var enterBtn = document.getElementById("enter");
var list = document.querySelector("ul");
var item = document.getElementsByTagName("li");

function inputLength(){
	return input.value.length;
} 

function listLength(){
	return item.length;
}

function createElementList()
{
    var li = document.createElement("li");
    li.appendChild(document.createTextNode(input.value));
    list.appendChild(li);
    input.value = "";
    var btn = document.createElement("button");
    btn.appendChild(document.createTextNode("X"));
    li.appendChild(btn);
    
    function crossOut() {
		li.classList.toggle("done");
	}

	li.addEventListener("click",crossOut);
     
    btn.addEventListener("click", deleteListItem);
	
	function deleteListItem(){
		li.classList.add("delete");
	}
}

function addListAfterClick(){
	if (inputLength() > 0) { 
		createElementList();
	}
}

function addListAfterKeypress(event) {
	if (inputLength() > 0 && event.which === 13) { 
		createElementList();
	} 
}


enterBtn.addEventListener("click",addListAfterClick);

input.addEventListener("keypress", addListAfterKeypress);

